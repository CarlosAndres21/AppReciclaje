# AppReciclaje
Desarrollo de una aplicación móvil para el reciclaje 
# Tareas para el usuario
## 1. Registro una cuenta
* Abre la aplicacion 
* da en el boton de registrarse 
* llena todos los campos 
* da en el boton de crear cuenta 
## 2. Conctacto recicladores 
* 
* 
* 
* 
* 
## 3. Poder ver la ubicación de los puntos de reciclaje
* Va al menu principal
* escoge la opcion de puntos de reciclaje 
* da click en el boton de ubicacion 
* se le despliega un mapa con su ubicacion y sectores donde hay puntos de reciclaje
## 4. Poder consultar sobre eventos de reciclaje
* Va al menu principal 
* escoge la opcion de eventos de reciclaje
* podra observar diferentes eventos 
## 5. Aprender a cómo reciclar
* Ingresa al menú principal 
* esoge la opcion de pasos para reciclar 
* se le despliega varias opciones de reciclaje
* escoge la opcion que desea ára reciclar 
* se le mostrara pasos a seguir sobre el material que escogio para reciclar 


